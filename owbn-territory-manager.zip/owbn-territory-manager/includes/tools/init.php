<?php

/** File: tools/init.php
 * Text Domain: owbn-territory-manager
 * Version: 0.9.0
 * @author greghacke
 * Function: Load tools
 */

defined('ABSPATH') || exit;

require_once __DIR__ . '/get-cc-data.php';
