<?php

/** File: core/activation.php
 * Text Domain: owbn-territory-manager
 * version 1.0.0
 * @author greghacke
 * Function: 
 */

defined('ABSPATH') || exit;
