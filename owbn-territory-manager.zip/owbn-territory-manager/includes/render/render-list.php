<?php

/** File: render/render-list.php
 * Text Domain: owbn-territory-manager
 * version 1.1.0
 * @author greghacke
 * Function: 
 */

defined('ABSPATH') || exit;
