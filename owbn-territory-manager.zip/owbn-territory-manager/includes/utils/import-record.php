<?php

/** File: utils/import-record.php
 * Text Domain: owbn-territory-manager
 * Version: 0.9.0
 * @author greghacke
 * Function: Import single record from CSV/Excel
 */

defined('ABSPATH') || exit;
