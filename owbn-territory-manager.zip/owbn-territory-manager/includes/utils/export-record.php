<?php

/** File: utils/export-record.php
 * Text Domain: owbn-territory-manager
 * Version: 1.1.0
 * @author greghacke
 * Function: Bulk import territories from CSV/Excel
 */

defined('ABSPATH') || exit;
