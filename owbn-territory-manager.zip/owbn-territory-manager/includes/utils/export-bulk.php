<?php

/** File: utils/export-bulk.php
 * Text Domain: owbn-territory-manager
 * Version: 1.1.0
 * @author greghacke
 * Function: Bulk export territories to CSV
 */

defined('ABSPATH') || exit;
