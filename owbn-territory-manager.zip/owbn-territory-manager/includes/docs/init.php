<?php

/** File: docs/init.php
 * Text Domain: owbn-territory-manager
 * version 0.9.0
 * @author greghacke
 * Function: 
 */

defined('ABSPATH') || exit;
